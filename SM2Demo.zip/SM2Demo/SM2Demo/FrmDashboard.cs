﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient; //for database
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SM2Demo
{
    public partial class FrmDashboard : Form
    {
        public FrmDashboard()
        {
            InitializeComponent();
        }

        private void btnInsert_Click(object sender, EventArgs e)
        {

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            string input = "admin";
            string conString = "Data Source=rs\\sqlstudents;Initial Catalog=POSDB;Integrated Security=True";
            string query = "select password from tblUsers where username = 'admin'";
            SqlConnection conn = new SqlConnection(conString);
            SqlCommand cmd = new SqlCommand(query, conn);
            conn.Open();
            string correct_pass = (string)cmd.ExecuteScalar();
            MessageBox.Show("Your correct password is " + correct_pass);
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
